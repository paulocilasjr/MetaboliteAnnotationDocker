library(testthat)
library(MatrixGenerics)

test_check("MatrixGenerics")
