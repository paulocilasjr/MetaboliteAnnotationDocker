require("GenomeInfoDb") || stop("unable to load GenomeInfoDb package")
GenomeInfoDb:::.test()
