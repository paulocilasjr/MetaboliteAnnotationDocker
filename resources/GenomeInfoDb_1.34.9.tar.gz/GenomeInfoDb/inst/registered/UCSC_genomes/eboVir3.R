GENOME <- "eboVir3"
ORGANISM <- "Zaire ebolavirus"
ASSEMBLED_MOLECULES <- "KM034562v1"
CIRC_SEQS <- character(0)

