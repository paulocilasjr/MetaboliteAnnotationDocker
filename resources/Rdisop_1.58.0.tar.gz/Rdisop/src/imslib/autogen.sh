autoreconf -i
libtoolize --copy --force --automake
