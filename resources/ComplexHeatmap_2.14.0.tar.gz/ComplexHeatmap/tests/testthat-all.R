

suppressWarnings(suppressPackageStartupMessages(library(ComplexHeatmap)))
library(testthat)

test_check("ComplexHeatmap")
