[<img src="https://www.bioconductor.org/images/logo/jpg/bioconductor_logo_rgb.jpg" width="200" align="right"/>](https://bioconductor.org/)

**zlibbioc** is an R/Bioconductor package that provides an R packaged zlib-1.2.5.

See https://bioconductor.org/packages/zlibbioc for more information including how to install the release version of the package (please refrain from installing directly from GitHub).

