library("testthat")
library("ProtGenerics")

test_check("ProtGenerics")
